# Local Http & Smtp Server

A basic http server to serve http request and,
A simple SMTP server to receive email


![Visitor Badge](https://visitor-badge.laobi.icu/badge?page_id=ajeetx/smtpserver)

